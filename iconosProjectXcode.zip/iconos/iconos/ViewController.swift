//
//  ViewController.swift
//  iconos
//
//  Created by funcoleto on 20/05/2024.
//

import Cocoa

import Foundation
import AppKit
import ImageIO
import UserNotifications


class ViewController: NSViewController {

    
    @IBOutlet weak var foto: NSImageView!
    
    
    @IBOutlet weak var multi: NSButton!
    
    @IBOutlet weak var iphoneos: NSButton!
    
    @IBOutlet weak var ipad: NSButton!
    
    @IBOutlet weak var macos: NSButton!
    
    @IBOutlet weak var watchos: NSButton!
    
    @IBOutlet weak var tvos: NSButton!
    
    @IBOutlet weak var otros: NSButton!
    
    @IBOutlet weak var carplay: NSButton!
    
    
    
    
    @IBOutlet weak var personalizados: NSTextField!
    
    
    var fotoSubida: Bool = false
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.personalizados.isEnabled = false
        self.personalizados.isHidden = true
        
        requestNotificationAuthorization()
        
        
        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


    
    
    @IBAction func subirFoto(_ sender: NSButton) {
        
        self.fotoSubida = true
        
        
        let openPanel = NSOpenPanel()
                openPanel.allowsMultipleSelection = false
                openPanel.canChooseDirectories = false
                openPanel.canCreateDirectories = false
                openPanel.canChooseFiles = true
                openPanel.allowedFileTypes = ["png", "jpg", "jpeg", "gif"]

                openPanel.begin { (result) -> Void in
                    if result.rawValue == NSApplication.ModalResponse.OK.rawValue {
                        let selectedPath = openPanel.url!.path
                        print("Archivo seleccionado: \(selectedPath)")
                        // Aquí puedes añadir el código para manejar la imagen seleccionada
                        
                        // Cargar la imagen en el NSImageView
                        let image = NSImage(byReferencing: openPanel.url!)
                        //self.foto.image = image
                        
                        
                       
                        
                        let metadata: [String: String] = ["AplicacionMac": "IconosApp", "Dev": "Funcoleto"]
                        
                        self.foto.image = self.addMetadataToImage(image: image, metadata: metadata)
                        
                        self.printImageMetadata(image: self.foto.image!)
                        
                        
                    }
                }
        
        
        
        
        
        
        
    }
    
    
    
    @IBAction func otrosBoton(_ sender: NSButton) {
        
        if (self.otros.state == .on){
            self.personalizados.isEnabled = true
            self.personalizados.isHidden = false
        }else if(self.otros.state == .off){
            self.personalizados.isEnabled = false
            self.personalizados.isHidden = true
        }
        
        
        
        
    }
    
    
    @IBAction func multiplataforma(_ sender: NSButton) {
        
        if (self.multi.state == .on){
            self.ipad.state = .on
            self.iphoneos.state = .on
            self.macos.state = .on
            self.watchos.state = .on
            self.tvos.state = .on
            self.carplay.state = .on
        }else if(self.multi.state == .off){
            self.ipad.state = .off
            self.iphoneos.state = .off
            self.macos.state = .off
            self.watchos.state = .off
            self.tvos.state = .off
            self.carplay.state = .off
        }
        
        
        
    }
    
    
    
    
    
    
    
    var ip: String = "/40x40/60x60/58x58/87x87/80x80/120x120/180x180/1024x1024/"
    var ipa: String = "/20x20/29x29/40x40/58x58/76x76/80x80/152x152/167x167/1024x1024/"
    var ma: String = "/16x16/32x32/64x64/128x128/256x256/512x512/1024x1024/"
    var wa: String = "/48x48/55x55/58x58/87x87/80x80/88x88/100x100/172x172/196x196/216x216/1024x1024/"
    var tv: String = "/1280x768/400x240/2320x720/4640x1440/1920x720/3840x1440/"
    var ca: String = "/120x120/180x180/"
    var ot: String = ""
    
    
    
    
    
    
    @IBAction func crearImagenes(_ sender: NSButton) {
        if(self.fotoSubida == true){
            
            
            
            if(self.iphoneos.state == .on){
             
                
                let sizes = ip.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/IphoneOs").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
        
        
            
            if(self.ipad.state == .on){
             
                
                let sizes = ipa.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/IpadOs").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
            
            
            if(self.macos.state == .on){
             
                
                let sizes = ma.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/MacOs").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
            
        
            if(self.watchos.state == .on){
             
                
                let sizes = wa.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/WatchOs").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
        
            if(self.tvos.state == .on){
             
                
                let sizes = tv.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/TvOs").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
            
            
            
            if(self.carplay.state == .on){
             
                
                let sizes = ca.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/CarPlay").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
            
            
            if(self.otros.state == .on){
             
                self.ot = self.personalizados.stringValue
                
                
                let sizes = ot.components(separatedBy: "/").filter { !$0.isEmpty }
                    let fileManager = FileManager.default
                let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/iconosApp/Otros").path
                        
                        print(directory)
                    
                    do {
                        try fileManager.createDirectory(atPath: directory, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Error creando directorio: \(error)")
                    }
                    
                    for size in sizes {
                        let dimensions = size.components(separatedBy: "x").compactMap { Int($0) }
                        guard dimensions.count == 2 else { continue }
                        
                        let resizedImage = resizeImage(image: foto.image!, width: dimensions[0], height: dimensions[1])
                        let imageData = resizedImage.tiffRepresentation
                        let fileURL = URL(fileURLWithPath: "\(directory)/\(size).png")
                        
                        do {
                            try imageData?.write(to: fileURL)
                        } catch {
                            print("Error escribiendo imagen: \(error)")
                        }
                    }
                
               
            }
            
            
            self.multi.state = .off
            self.ipad.state = .off
            self.iphoneos.state = .off
            self.macos.state = .off
            self.watchos.state = .off
            self.tvos.state = .off
            self.carplay.state = .off
            self.otros.state = .off
            self.personalizados.stringValue = ""
            self.personalizados.isHidden = true
            self.fotoSubida = false
        
        
        
            self.alerta(titulo: "IconosApp", mensaje: "Se crearon sus iconos, se encontraran en la carpeta 'DESCARGAS'", boton: "Ok")
        }
    }
    
    
    
    func resizeImage(image: NSImage, width: Int, height: Int) -> NSImage {
        let imgData = image.tiffRepresentation!
        let imgRep = NSBitmapImageRep(data: imgData)!
        let imgSize = NSMakeSize(CGFloat(width), CGFloat(height))
        
        let newImage = NSImage(size: imgSize)
        newImage.lockFocus()
        imgRep.draw(in: NSMakeRect(0, 0, imgSize.width, imgSize.height))
        newImage.unlockFocus()
        
        return newImage
    }
    
    
    
 
    
    func requestNotificationAuthorization() {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound]) { (granted, error) in
            if granted {
                print("Permiso para notificaciones concedido")
                
                
                
                
            } else {
                print("Permiso para notificaciones denegado")
            }
        }
    }
    
    
    
    func alerta(titulo:String, mensaje:String, boton:String) {
        let alert = NSAlert()
        alert.messageText = titulo
        alert.informativeText = mensaje
        alert.alertStyle = .informational
        alert.icon = NSApp.applicationIconImage
        alert.addButton(withTitle: boton)
        //alert.addButton(withTitle: "Cancelar")
        alert.runModal()
    }
    
    

    func addMetadataToImage(image: NSImage, metadata: [String: String]) -> NSImage? {
        var imageRect = CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height)
        guard let cgImage = image.cgImage(forProposedRect: &imageRect, context: nil, hints: nil),
              let mutableData = CFDataCreateMutable(nil, 0),
              let destination = CGImageDestinationCreateWithData(mutableData, cgImage.utType!, 1, nil) else {
            print("No se pudo crear la imagen o el destino")
            return nil
        }
        
        // Añade la imagen original al destino
        CGImageDestinationAddImage(destination, cgImage, nil)
        
        // Crea un diccionario con los metadatos que quieres añadir
        let metadataProperties = [kCGImagePropertyExifDictionary: metadata]
        
        // Añade los metadatos a la imagen en el destino
        CGImageDestinationSetProperties(destination, metadataProperties as CFDictionary)
        
        // Finaliza el destino, lo que causa que se escriban los datos en el objeto de datos mutable
        if CGImageDestinationFinalize(destination) {
            print("Se añadieron metadatos a la imagen con éxito")
            
            // Crea una nueva NSImage con los metadatos añadidos
            let data = mutableData as Data
            let newImage = NSImage(data: data)
            return newImage
        } else {
            print("No se pudo añadir metadatos a la imagen")
            return nil
        }
    }
    
    
    
    func printImageMetadata(image: NSImage) {
        guard let tiffData = image.tiffRepresentation,
              let imageSource = CGImageSourceCreateWithData(tiffData as CFData, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [CFString: Any] else {
            print("No se pudo crear la imagen o el origen de la imagen")
            return
        }
        print("Metadatos de la imagen: \(metadata)")
    }
    
    
    
    
    
}

